Trades of the fixture.
